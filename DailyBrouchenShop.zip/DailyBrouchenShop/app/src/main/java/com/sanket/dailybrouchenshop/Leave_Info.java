package com.sanket.dailybrouchenshop;

public class Leave_Info {

    public String leaveStartDate;
    public String leaveEndDate;
    public String leaveReason;

    public Leave_Info(){}

    public Leave_Info(String leaveStartDate1,String leaveEndDate1,String leaveReason1)
    {
        this.leaveStartDate=leaveStartDate1;
        this.leaveEndDate=leaveEndDate1;
        this.leaveReason=leaveReason1;
    }


}
