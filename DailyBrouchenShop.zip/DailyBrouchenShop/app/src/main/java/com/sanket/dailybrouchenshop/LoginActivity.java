package com.sanket.dailybrouchenshop;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;


public class LoginActivity extends AppCompatActivity {

    FirebaseAuth emailAuth;

    Button btnLogin;
    EditText editEmail,editPass;
    String loginEmail,loginPassword;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        emailAuth=FirebaseAuth.getInstance();

        btnLogin=findViewById(R.id.btnLoginSubmit);
        editEmail=findViewById(R.id.editLoginEmail);
        editPass=findViewById(R.id.editLoginPassword);



        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loginEmail=editEmail.getText().toString().trim();
                loginPassword=editPass.getText().toString().trim();
                email_signIn(loginEmail,loginPassword);
            }
        });



    }

    void email_signIn(String e1,String p1)
    {
        emailAuth.signInWithEmailAndPassword(e1,p1).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {

                if(task.isSuccessful()){
                    FirebaseUser c1User=emailAuth.getCurrentUser();
                    user_avail(c1User);

                }
                else {
                    Toast.makeText(getApplicationContext(),"Authentication Failed",Toast.LENGTH_SHORT).show();
                }

            }
        });
    }



    void user_avail(FirebaseUser cUser)
    {
        Toast.makeText(getApplicationContext(),"Current User is : "+cUser.getEmail(),Toast.LENGTH_SHORT).show();
        startActivity(new Intent(LoginActivity.this,MainActivity.class));
    }



    //StartMethod
    @Override
    protected void onStart() {
        FirebaseUser currentUser=emailAuth.getCurrentUser();

        if (currentUser!=null)
        {
            user_avail(currentUser);
        }



        super.onStart();
    }
}
