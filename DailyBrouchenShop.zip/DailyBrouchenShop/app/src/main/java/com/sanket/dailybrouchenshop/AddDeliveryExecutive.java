package com.sanket.dailybrouchenshop;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class AddDeliveryExecutive extends AppCompatActivity {
    EditText editDeliverFullName,editDeliverEmail,editDeliverPhoneNo,editDeliverAddress,editDeliverPassword,editDeliverDOB;
    Button btnDeliverSubmit,btnDeliverCancel;



    FirebaseDatabase database_shop;
    FirebaseAuth mAuth;
    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_delivery_executive);

        editDeliverFullName=findViewById(R.id.editDeliverFullName);
        editDeliverAddress=findViewById(R.id.editDeliverAddress);
        editDeliverEmail=findViewById(R.id.editDeliverEmail);
        editDeliverDOB=findViewById(R.id.editDeliverDOB);
        editDeliverPhoneNo=findViewById(R.id.editDeliverContactNo);
        editDeliverPassword=findViewById(R.id.editDeliverPassword);

        btnDeliverSubmit=findViewById(R.id.btnDeliverSubmit);
        btnDeliverCancel=findViewById(R.id.btnDeliverCancel);

        mAuth=FirebaseAuth.getInstance();
        database_shop=FirebaseDatabase.getInstance();
        databaseReference=database_shop.getReference("delivery_executive");


        btnDeliverSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String a1=editDeliverFullName.getText().toString().trim();
                String a2=editDeliverEmail.getText().toString().trim();
                String a3=editDeliverPhoneNo.getText().toString().trim();
                String a4=editDeliverAddress.getText().toString().trim();
                String a5=editDeliverDOB.getText().toString().trim();
                String a6=editDeliverPassword.getText().toString().trim();



                Long tsLong = System.currentTimeMillis()/1000;
                String ts = tsLong.toString();

                DeliveryExecutive_Info deliveryExecutive_info=new DeliveryExecutive_Info(a1,a2,a3,a4,a5,a6);
                databaseReference.child(""+mAuth.getCurrentUser().getUid()+"_"+ts).child("personal_details").setValue(deliveryExecutive_info);





                editDeliverFullName.setText("");
                editDeliverAddress.setText("");
                editDeliverDOB.setText("");
                editDeliverEmail.setText("");
                editDeliverPassword.setText("");
                editDeliverPhoneNo.setText("");

                Toast.makeText(getApplicationContext(),"Delivery Executive Added Successfully..!",Toast.LENGTH_SHORT).show();
                startActivity(new Intent(AddDeliveryExecutive.this,MainActivity.class));



            }
        });



    }
}
