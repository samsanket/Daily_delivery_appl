package com.sanket.dailybrouchenshop;

public class Product_info {

    public String product_name;
    public String product_cat;
    public String product_val;
    public String product_price;
    public String product_quantity;

    public Product_info(){

    }

    public Product_info(String product_name1,String product_cat1,String product_val1,String product_price1,String product_quantity1)
    {
        this.product_name=product_name1;
        this.product_cat=product_cat1;
        this.product_val=product_val1;
        this.product_price=product_price1;
        this.product_quantity=product_quantity1;
    }

}
