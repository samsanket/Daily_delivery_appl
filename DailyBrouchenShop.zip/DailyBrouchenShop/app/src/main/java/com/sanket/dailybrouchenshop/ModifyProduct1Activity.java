package com.sanket.dailybrouchenshop;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class ModifyProduct1Activity extends AppCompatActivity {


    EditText editProductIdModifyProduct;
    Button btnSubmitModifyProduct;
    TextView txtGoBackModifyProduct;
    String s1;
    int flag1=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modify_product1);

        editProductIdModifyProduct=findViewById(R.id.editProductIdModifyProduct);
        btnSubmitModifyProduct=findViewById(R.id.btnSubmitModifyProduct);
        txtGoBackModifyProduct=findViewById(R.id.txtGoBackModifyProduct);



        btnSubmitModifyProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                s1=editProductIdModifyProduct.getText().toString().trim();
                editProductIdModifyProduct.setText("");
                Intent i1=new Intent(ModifyProduct1Activity.this,ModifyProduct2Activity.class);
                i1.putExtra("prd_id",""+s1);


                FirebaseAuth mAuth=FirebaseAuth.getInstance();
                DatabaseReference databaseReference= FirebaseDatabase.getInstance().getReference("shop").child(""+mAuth.getCurrentUser().getUid()).child("product_details").child(s1);
                databaseReference.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            if (dataSnapshot.hasChildren())
                            {
                                //Toast.makeText(getApplicationContext(),"YYy",Toast.LENGTH_SHORT).show();
                                flag1=1;
                            }

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });

                if (flag1==1)
                {
                    startActivity(i1);
                }else {
                    Toast.makeText(getApplicationContext(),"Product ID not found",Toast.LENGTH_SHORT).show();
                }


            }
        });

        txtGoBackModifyProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ModifyProduct1Activity.this,MainActivity.class));
            }
        });

    }
}
