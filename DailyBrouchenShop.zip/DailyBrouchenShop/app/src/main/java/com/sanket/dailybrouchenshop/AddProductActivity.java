package com.sanket.dailybrouchenshop;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class AddProductActivity extends AppCompatActivity {


    EditText editProductName,editProductCat,editProductValid,editProductPrice,editProductQuantity;
    Button btnSubmit,btnCancel;


    FirebaseDatabase database_shop;
    FirebaseAuth mAuth;
    DatabaseReference databaseReference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_product);
        mAuth=FirebaseAuth.getInstance();
        database_shop=FirebaseDatabase.getInstance();
        databaseReference=database_shop.getReference("shop");


        editProductName=findViewById(R.id.editProductNameAddProduct);
        editProductCat=findViewById(R.id.editProductCateAddProduct);
        editProductValid=findViewById(R.id.editValidityAddProduct);
        editProductPrice=findViewById(R.id.editPriceAddProduct);
        editProductQuantity=findViewById(R.id.editQuantityAddProduct);

        btnSubmit=findViewById(R.id.btnSubmitAddProduct);
        btnCancel=findViewById(R.id.btnCancelAddProduct);




            btnSubmit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    String a1=editProductName.getText().toString().trim();
                    String a2=editProductCat.getText().toString().trim();
                    String a3=editProductValid.getText().toString().trim();
                    String a4=editProductPrice.getText().toString().trim();
                    String a5=editProductQuantity.getText().toString().trim();

                    editProductCat.setText("");
                    editProductName.setText("");
                    editProductPrice.setText("");
                    editProductQuantity.setText("");
                    editProductValid.setText("");

                    Long tsLong = System.currentTimeMillis()/1000;
                    String ts = tsLong.toString();
                    Product_info product1=new Product_info(a1,a2,a3,a4,a5);
                    databaseReference.child(""+mAuth.getCurrentUser().getUid()).child("product_details").child(""+ts).setValue(product1);

                }
            });


            btnCancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    editProductCat.setText("");
                    editProductName.setText("");
                    editProductPrice.setText("");
                    editProductQuantity.setText("");
                    editProductValid.setText("");

                }
            });















    }
}
