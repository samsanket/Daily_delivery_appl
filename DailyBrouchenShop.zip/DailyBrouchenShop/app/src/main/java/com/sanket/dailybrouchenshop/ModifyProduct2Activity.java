package com.sanket.dailybrouchenshop;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ModifyProduct2Activity extends AppCompatActivity {
    String getPrd_id;
    Button btnSubmitModifyProduct,btnCancelModifyProduct;
    FirebaseAuth mAuth;


    EditText editProductNameModifyProduct,editProductCateModifyProduct,editValidityModifyProduct,editPriceModifyProduct,editQuantityModifyProduct;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modify_product2);
        getPrd_id=getIntent().getStringExtra("prd_id");
        btnSubmitModifyProduct=findViewById(R.id.btnSubmitModify2Product);
        btnCancelModifyProduct=findViewById(R.id.btnCancelModifyProduct);
        editProductNameModifyProduct=findViewById(R.id.editProductNameModifyProduct);
        editProductCateModifyProduct=findViewById(R.id.editProductCateModifyProduct);
        editValidityModifyProduct=findViewById(R.id.editValidityModifyProduct);
        editPriceModifyProduct=findViewById(R.id.editPriceModifyProduct);
        editQuantityModifyProduct=findViewById(R.id.editQuantityModifyProduct);

        mAuth=FirebaseAuth.getInstance();

        DatabaseReference databaseReference= FirebaseDatabase.getInstance().getReference("shop").child(""+mAuth.getCurrentUser().getUid()).child("product_details").child(getPrd_id);
        databaseReference.addValueEventListener(new ValueEventListener() {
                      @Override
                      public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                          String s21=dataSnapshot.child("product_name").getValue().toString();
                          String s22=dataSnapshot.child("product_cat").getValue().toString();
                          String s23=dataSnapshot.child("product_val").getValue().toString();
                          String s24=dataSnapshot.child("product_price").getValue().toString();
                          String s25=dataSnapshot.child("product_quantity").getValue().toString();


                          editProductNameModifyProduct.setText(s21);
                          editProductCateModifyProduct.setText(s22);
                          editValidityModifyProduct.setText(s23);
                          editPriceModifyProduct.setText(s24);
                          editQuantityModifyProduct.setText(s25);
                          //Toast.makeText(getApplicationContext(),""+s23,Toast.LENGTH_SHORT).show();
 }

                      @Override
                      public void onCancelled(@NonNull DatabaseError databaseError) {

                        Toast.makeText(getApplicationContext(),"Something went wrong..!",Toast.LENGTH_SHORT).show();
                      }
                  });



        btnSubmitModifyProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                DatabaseReference databaseReference1= FirebaseDatabase.getInstance().getReference("shop").child(""+mAuth.getCurrentUser().getUid()).child("product_details").child(getPrd_id);


                String s21=editProductNameModifyProduct.getText().toString().trim();
                String s22=editProductCateModifyProduct.getText().toString().trim();
                String s23=editValidityModifyProduct.getText().toString().trim();
                String s24=editPriceModifyProduct.getText().toString().trim();
                String s25=editQuantityModifyProduct.getText().toString().trim();

                Product_info product_info=new Product_info(s21,s22,s23,s24,s25);


                databaseReference1.setValue(product_info);

                Toast.makeText(getApplicationContext(),"Product Modified Successfully..!",Toast.LENGTH_SHORT).show();

                editProductNameModifyProduct.setText("");
                editProductCateModifyProduct.setText("");
                editValidityModifyProduct.setText("");
                editPriceModifyProduct.setText("");
                editQuantityModifyProduct.setText("");

                startActivity(new Intent(ModifyProduct2Activity.this,ModifyProduct1Activity.class));
            }
        });





    }
}


/**
 *
 *      For Reading data
 *
 * DatabaseReference databaseReference= FirebaseDatabase.getInstance().getReference("shop").child(""+mAuth.getCurrentUser().getUid()).child("product_details").child(getPrd_id);
 *
 *
 *                 databaseReference.addValueEventListener(new ValueEventListener() {
 *                     @Override
 *                     public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
 *
 *                         dataSnapshot.child("product_name").toString();
 *
 *                         Product_info product_info=new Product_info("Milk 300g1","Daily Needs1","20/10/2020","101","201");
 *
 *                         Toast.makeText(getApplicationContext(),""+dataSnapshot.getValue(),Toast.LENGTH_SHORT).show();
 *
 *
 *                     }
 *
 *                     @Override
 *                     public void onCancelled(@NonNull DatabaseError databaseError) {
 *
 *                     }
 *                 });
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */
