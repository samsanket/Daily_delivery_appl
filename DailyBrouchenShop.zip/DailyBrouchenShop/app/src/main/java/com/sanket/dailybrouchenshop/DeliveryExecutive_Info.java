package com.sanket.dailybrouchenshop;

public class DeliveryExecutive_Info {

    public String full_name1,email1,contact1,address1,dob1,pass1;

    public DeliveryExecutive_Info(){}

    public DeliveryExecutive_Info(String a21,String a22, String a23, String a24, String a25, String a26){

        this.full_name1=a21;
        this.email1=a22;
        this.contact1=a23;
        this.address1=a24;
        this.dob1=a25;
        this.pass1=a26;

    }
}
