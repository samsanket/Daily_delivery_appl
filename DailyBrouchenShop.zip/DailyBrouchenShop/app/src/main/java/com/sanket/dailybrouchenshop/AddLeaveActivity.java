package com.sanket.dailybrouchenshop;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Date;

public class AddLeaveActivity extends AppCompatActivity {

    EditText editLeaveStartDate,editLeaveEndDate,editLeaveReason;
    Button btnSubmitLeave;



    FirebaseDatabase database_shop;
    FirebaseAuth mAuth;
    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_leave);

        editLeaveStartDate=findViewById(R.id.editLeaveStartDate);
        editLeaveEndDate=findViewById(R.id.editLeaveEndDate);
        editLeaveReason=findViewById(R.id.editLeaveReason);
        btnSubmitLeave=findViewById(R.id.btnSubmitLeave);

        mAuth=FirebaseAuth.getInstance();
        database_shop=FirebaseDatabase.getInstance();
        databaseReference=database_shop.getReference("shop");



        btnSubmitLeave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String a1=editLeaveStartDate.getText().toString().trim();
                String a2=editLeaveEndDate.getText().toString().trim();
                String a3=editLeaveReason.getText().toString().trim();

                Leave_Info leave_info=new Leave_Info(a1,a2,a3);

                Long tsLong = System.currentTimeMillis()/1000;
                String ts = tsLong.toString();

                databaseReference.child(""+mAuth.getCurrentUser().getUid()).child("leave_details").child(""+ts).setValue(leave_info);

                editLeaveStartDate.setText("");
                editLeaveEndDate.setText("");
                editLeaveReason.setText("");
                Toast.makeText(getApplicationContext(),"Leave Added..!",Toast.LENGTH_SHORT).show();
                startActivity(new Intent(AddLeaveActivity.this,MainActivity.class));
            }
        });

    }
}
